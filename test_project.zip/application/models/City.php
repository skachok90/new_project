<?php
class City extends Model_Abstract
{
}
