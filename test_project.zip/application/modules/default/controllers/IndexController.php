<?php
class IndexController extends Controller_Abstract
{
	public function indexAction()
	{
		$country = new Country();
		
		if($this->_params['country_id']) {
			$cities = $country->getCitiesById($this->_params['country_id']);
			echo json_encode($cities);
			exit;
		}
		
		return $this->view->assign(array(
			'countries' => $country->getAll()
		));
	}
}
